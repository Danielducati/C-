﻿namespace DogApiDemo.Models
{
    public class DogApiResponse<T>
    {
        public T Message { get; set; }
        public string Status { get; set; }
    }
}
