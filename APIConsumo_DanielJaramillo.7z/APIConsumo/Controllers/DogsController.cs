﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using System.Text.Json;

namespace APIConsumo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DogsController : ControllerBase
    {
        private readonly HttpClient _httpClient;

        public DogsController()
        {
            _httpClient = new HttpClient();
        }

        [HttpGet("random")]
        public async Task<IActionResult> GetRandomDog()
        {
            var response = await _httpClient.GetStringAsync("https://dog.ceo/api/breeds/image/random");

            // Parsear JSON para que quede más limpio
            var json = JsonDocument.Parse(response);
            var imageUrl = json.RootElement.GetProperty("message").GetString();

            return Ok(new { image = imageUrl });
        }
    }
}
